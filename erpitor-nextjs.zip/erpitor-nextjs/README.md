# ERPitor website (Next.js)

Production-ready, bilingual (ET/EN) Next.js website template for ERPitor.

## Features
- Next.js + TypeScript + Tailwind CSS
- Bilingual routing (default **et**, English under **/en**) via Next.js i18n
- SEO basics: canonical URLs, `hreflang` alternates, OpenGraph, sitemap.xml, robots.txt
- Pages: Home, Services, Industries, Case Studies, About, Blog, Contact (+ Privacy placeholder)
- File-based blog content (`src/content/blog/<locale>/*.md`) with frontmatter
- Contact form + API route (`/api/contact`) using SMTP (Nodemailer)

---

## Quick start

```bash
npm install
npm run dev
```

Build:

```bash
npm run build
npm run start
```

---

## Configure site URL (SEO)

Set the public site URL for canonical/hreflang:

Create `.env.local`:

```bash
NEXT_PUBLIC_SITE_URL=https://www.erpitor.com
```

---

## Configure contact form email (SMTP)

The contact form posts to `/api/contact`.

Add to `.env.local`:

```bash
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=your-smtp-username
SMTP_PASS=your-smtp-password

CONTACT_FROM="Erpitor OÜ <no-reply@erpitor.com>"
CONTACT_TO="mnafthal@erpitor.com"
```

> Tip: If you plan to use Gmail, use an **App Password** (not your normal password) and consider a dedicated mailbox for sending.

---

## Content editing

- Dictionaries (copy/labels): `src/content/dictionaries/et.json` and `src/content/dictionaries/en.json`
- Case studies: `src/content/case-studies.ts`
- Blog posts: `src/content/blog/<locale>/*.md`

---

## Deployment

Works well on:
- Vercel
- Netlify (Next runtime)
- Any Node.js hosting

---

## Security note

Your previous PHP contact form used **hardcoded SMTP credentials**. For safety:
- remove hardcoded credentials from any repo
- rotate/revoke old credentials and generate new ones
- use environment variables (as shown above)

