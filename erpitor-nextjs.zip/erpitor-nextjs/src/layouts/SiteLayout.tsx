import type { ReactNode } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import type { Dictionary } from "@/lib/i18n";

export function SiteLayout({
  children,
  dict,
}: {
  children: ReactNode;
  dict: Dictionary;
}) {
  return (
    <div className="min-h-screen bg-white">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-sm focus:shadow">
        Skip to content
      </a>
      <SiteHeader nav={dict.nav} ctaLabel={dict.cta.freeConsultation} />
      <main id="main">{children}</main>
      <SiteFooter copyright={dict.footer.copyright} />
    </div>
  );
}
