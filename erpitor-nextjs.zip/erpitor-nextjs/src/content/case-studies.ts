export type CaseStudy = {
  id: string;
  featured?: boolean;
  company: string;
  country: string;
  years: string;
  product: "Epicor Kinetic" | "Epicor ERP" | "Epicor iScala" | "Other";
  tags: string[];
  summary: {
    en: string;
    et: string;
  };
};

export const caseStudies: CaseStudy[] = [
  {
    id: "vishay-nobel",
    featured: true,
    company: "Vishay Nobel AB",
    country: "Sweden",
    years: "2021–2022",
    product: "Epicor Kinetic",
    tags: ["Manufacturing", "Logistics", "Kinetic 2021"],
    summary: {
      en: "Lead consultant for the implementation of Kinetic 2021 with focus on production and logistics modules.",
      et: "Juhtkonsultant Kinetic 2021 juurutuses, fookus tootmise ja logistika moodulitel.",
    },
  },
  {
    id: "kiilto",
    featured: true,
    company: "Kiilto Oy / KiiltoClean Oy",
    country: "Finland + Baltics/Russia",
    years: "2008–2013",
    product: "Epicor ERP",
    tags: ["Multi-company", "Manufacturing", "Logistics"],
    summary: {
      en: "Lead consulting for Epicor 9 manufacturing and logistics across multiple companies and locations.",
      et: "Juhtkonsultatsioon Epicor 9 tootmise ja logistika juurutustes mitmes ettevõttes ja asukohas.",
    },
  },
  {
    id: "blrt",
    featured: true,
    company: "BLRT Group (Elme Metall / Toorik)",
    country: "Estonia + Finland",
    years: "2014–2018",
    product: "Epicor ERP",
    tags: ["Group", "Manufacturing", "Logistics"],
    summary: {
      en: "Epicor 10 / 10.2 manufacturing and logistics implementation for multiple group companies.",
      et: "Epicor 10 / 10.2 tootmise ja logistika juurutus mitmele kontserni ettevõttele.",
    },
  },
  {
    id: "viljandi-aken-ja-uks",
    featured: true,
    company: "Viljandi Aken ja Uks AS",
    country: "Estonia",
    years: "2012–2013",
    product: "Epicor ERP",
    tags: ["Manufacturing", "Planning", "Inventory"],
    summary: {
      en: "Epicor 9 manufacturing and logistics rollout across four plants, improving planning and inventory control.",
      et: "Epicor 9 tootmise ja logistika juurutus neljas tehases, parendades planeerimist ja laohaldust.",
    },
  },
  {
    id: "cargotec-hiab",
    featured: true,
    company: "Cargotec HIAB",
    country: "Spain",
    years: "2018",
    product: "Epicor iScala",
    tags: ["Upgrade", "Web services", "Integrations"],
    summary: {
      en: "Upgraded iScala to 3.2 and delivered web services for external order management and reporting.",
      et: "iScala uuendus 3.2 versioonile ja veebiteenused välise tellimushalduse ning raportite jaoks.",
    },
  },
  {
    id: "marioff",
    company: "Marioff Oy",
    country: "Finland",
    years: "2009–2010",
    product: "Epicor iScala",
    tags: ["Manufacturing", "Logistics", "Finance"],
    summary: {
      en: "Implemented iScala manufacturing and logistics with general ledger integration.",
      et: "iScala tootmise ja logistika juurutus koos pearaamatu integratsiooniga.",
    },
  },
  {
    id: "loipart",
    company: "Loipart AB",
    country: "Sweden",
    years: "2014",
    product: "Epicor ERP",
    tags: ["Logistics", "Inventory"],
    summary: {
      en: "Implemented Epicor 10 logistics modules to streamline inventory and supply chain processes.",
      et: "Epicor 10 logistika moodulite juurutus laohalduse ja tarneahela sujuvamaks muutmiseks.",
    },
  },
  {
    id: "abb",
    company: "ABB AS",
    country: "Estonia",
    years: "2002",
    product: "Other",
    tags: ["Manufacturing", "Quality", "Reporting"],
    summary: {
      en: "Participated in manufacturing module implementation and reporting system design.",
      et: "Osales tootmismooduli juurutuses ja raportisüsteemi disainis.",
    },
  },
];
