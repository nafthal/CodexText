import { useRouter } from "next/router";
import { Button } from "@/components/Button";
import type { Locale } from "@/lib/i18n";
import { SITE } from "@/lib/site";

export function LanguageSwitcher() {
  const router = useRouter();
  const current = (router.locale || SITE.defaultLocale) as Locale;

  const other: Locale = current === "et" ? "en" : "et";

  function switchTo(locale: Locale) {
    // Keep the same path + query, only change locale.
    router.push({ pathname: router.pathname, query: router.query }, router.asPath, { locale });
  }

  return (
    <div className="flex items-center gap-2">
      <Button
        type="button"
        variant={current === "et" ? "secondary" : "ghost"}
        className="h-9 px-3"
        onClick={() => switchTo("et")}
        aria-pressed={current === "et"}
      >
        ET
      </Button>
      <Button
        type="button"
        variant={current === "en" ? "secondary" : "ghost"}
        className="h-9 px-3"
        onClick={() => switchTo("en")}
        aria-pressed={current === "en"}
      >
        EN
      </Button>
    </div>
  );
}
