import Head from "next/head";
import { useRouter } from "next/router";
import { SITE } from "@/lib/site";
import { absoluteUrl } from "@/lib/seo";

export function SEO({
  title,
  description,
  noIndex,
}: {
  title?: string;
  description?: string;
  noIndex?: boolean;
}) {
  const router = useRouter();
  const locale = router.locale || SITE.defaultLocale;
  const defaultLocale = router.defaultLocale || SITE.defaultLocale;

  const rawPath = (router.asPath || "/").split("?")[0] || "/";
  let basePath = rawPath;

  // Remove locale prefix to get the default-locale path (used for hreflang links).
  if (locale !== defaultLocale && basePath.startsWith(`/${locale}`)) {
    basePath = basePath.replace(`/${locale}`, "") || "/";
  }

  const canonical = absoluteUrl(rawPath);
  const altEt = absoluteUrl(basePath);
  const altEn = absoluteUrl(`/en${basePath === "/" ? "" : basePath}`);

  const fullTitle = title ? `${title} | ${SITE.name}` : undefined;

  return (
    <Head>
      <title>{fullTitle ?? undefined}</title>
      {description ? <meta name="description" content={description} /> : null}
      <link rel="canonical" href={canonical} />

      {/* hreflang alternates */}
      <link rel="alternate" hrefLang="et" href={altEt} />
      <link rel="alternate" hrefLang="en" href={altEn} />
      <link rel="alternate" hrefLang="x-default" href={altEt} />

      {/* Open Graph */}
      <meta property="og:site_name" content={SITE.name} />
      <meta property="og:url" content={canonical} />
      <meta property="og:type" content="website" />
      {fullTitle ? <meta property="og:title" content={fullTitle} /> : null}
      {description ? <meta property="og:description" content={description} /> : null}
      <meta property="og:locale" content={locale === "et" ? "et_EE" : "en_US"} />
      <meta property="og:image" content={absoluteUrl("/og.png")} />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />

      {/* Robots */}
      {noIndex ? (
        <meta name="robots" content="noindex, nofollow" />
      ) : (
        <meta name="robots" content="index, follow" />
      )}
    </Head>
  );
}
