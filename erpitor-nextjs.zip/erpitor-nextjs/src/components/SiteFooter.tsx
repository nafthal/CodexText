import Link from "next/link";
import { Container } from "@/components/Container";
import { SITE } from "@/lib/site";

export function SiteFooter({ copyright }: { copyright: string }) {
  const year = new Date().getFullYear();
  const text = copyright.replace("{year}", String(year));

  return (
    <footer className="border-t border-slate-200 bg-white">
      <Container className="py-10">
        <div className="grid gap-8 md:grid-cols-3">
          <div>
            <div className="text-sm font-semibold text-slate-900">{SITE.name}</div>
            <p className="mt-2 text-sm text-slate-600">
              ERP consulting and development for Epicor Kinetic and Epicor iScala.
            </p>
          </div>

          <div>
            <div className="text-sm font-semibold text-slate-900">Contact</div>
            <div className="mt-2 space-y-1 text-sm text-slate-600">
              <div>
                <Link href={`mailto:${SITE.contact.email}`} className="hover:text-brand-800">
                  {SITE.contact.email}
                </Link>
              </div>
              <div>
                <Link href={`tel:${SITE.contact.phone.replace(/\s+/g, "")}`} className="hover:text-brand-800">
                  {SITE.contact.phone}
                </Link>
              </div>
              <div>{SITE.contact.address}</div>
            </div>
          </div>

          <div>
            <div className="text-sm font-semibold text-slate-900">Quick links</div>
            <div className="mt-2 grid gap-2 text-sm text-slate-600">
              <Link href="/services" className="hover:text-brand-800">Services</Link>
              <Link href="/case-studies" className="hover:text-brand-800">Case studies</Link>
              <Link href="/blog" className="hover:text-brand-800">Blog</Link>
              <Link href="/contact" className="hover:text-brand-800">Contact</Link>
            </div>
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-2 border-t border-slate-200 pt-6 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <div>{text}</div>
          <div>
            <Link href="/privacy" className="hover:text-brand-800">Privacy</Link>
          </div>
        </div>
      </Container>
    </footer>
  );
}
