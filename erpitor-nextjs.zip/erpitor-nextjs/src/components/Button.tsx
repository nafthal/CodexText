import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost";
};

export function Button({ className, variant = "primary", ...props }: Props) {
  const base =
    "inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-brand-600 focus:ring-offset-2 disabled:opacity-60 disabled:cursor-not-allowed";
  const variants: Record<string, string> = {
    primary: "bg-brand-700 text-white hover:bg-brand-800",
    secondary: "bg-brand-50 text-brand-800 hover:bg-brand-100 border border-brand-200",
    ghost: "bg-transparent text-brand-800 hover:bg-brand-50",
  };
  return <button className={cn(base, variants[variant], className)} {...props} />;
}
