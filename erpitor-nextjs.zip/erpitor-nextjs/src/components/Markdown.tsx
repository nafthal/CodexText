import { cn } from "@/lib/utils";

export function Markdown({ html, className }: { html: string; className?: string }) {
  return (
    <div
      className={cn("prose prose-slate max-w-none prose-headings:scroll-mt-24", className)}
      // Content is built from trusted markdown in the repo.
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
