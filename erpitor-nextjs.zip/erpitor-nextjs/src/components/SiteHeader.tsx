import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import { Container } from "@/components/Container";
import { Button } from "@/components/Button";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";

type NavDict = {
  home: string;
  services: string;
  industries: string;
  caseStudies: string;
  about: string;
  blog: string;
  contact: string;
};

export function SiteHeader({
  nav,
  ctaLabel,
}: {
  nav: NavDict;
  ctaLabel: string;
}) {
  const router = useRouter();
  const currentPath = router.pathname;

  const isActive = (href: string) => {
    if (href === "/blog") return currentPath === "/blog" || currentPath.startsWith("/blog/");
    return currentPath === href;
  };

  const linkClass = (href: string) =>
    [
      "rounded-xl px-3 py-2 text-sm font-semibold transition",
      "hover:bg-brand-50 hover:text-brand-900",
      isActive(href) ? "bg-brand-50 text-brand-900" : "text-slate-700",
    ].join(" ");

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/80 backdrop-blur">
      <Container className="flex h-16 items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-3 no-underline" aria-label="ERPitor">
          <Image
            src="/branding/erpitor.png"
            alt="ERPITOR"
            width={140}
            height={38}
            priority
          />
        </Link>

        <nav className="hidden items-center gap-1 md:flex" aria-label="Main navigation">
          <Link className={linkClass("/")} href="/">
            {nav.home}
          </Link>
          <Link className={linkClass("/services")} href="/services">
            {nav.services}
          </Link>
          <Link className={linkClass("/industries")} href="/industries">
            {nav.industries}
          </Link>
          <Link className={linkClass("/case-studies")} href="/case-studies">
            {nav.caseStudies}
          </Link>
          <Link className={linkClass("/about")} href="/about">
            {nav.about}
          </Link>
          <Link className={linkClass("/blog")} href="/blog">
            {nav.blog}
          </Link>
          <Link className={linkClass("/contact")} href="/contact">
            {nav.contact}
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden sm:block">
            <LanguageSwitcher />
          </div>
          <Link href="/contact" className="no-underline">
            <Button className="hidden sm:inline-flex">{ctaLabel}</Button>
          </Link>
        </div>
      </Container>

      {/* Mobile nav */}
      <div className="border-t border-slate-200 md:hidden">
        <Container className="flex items-center justify-between py-2">
          <LanguageSwitcher />
          <Link href="/contact" className="no-underline">
            <Button>{ctaLabel}</Button>
          </Link>
        </Container>
        <Container className="flex flex-wrap gap-2 pb-3">
          <Link className={linkClass("/")} href="/">
            {nav.home}
          </Link>
          <Link className={linkClass("/services")} href="/services">
            {nav.services}
          </Link>
          <Link className={linkClass("/industries")} href="/industries">
            {nav.industries}
          </Link>
          <Link className={linkClass("/case-studies")} href="/case-studies">
            {nav.caseStudies}
          </Link>
          <Link className={linkClass("/about")} href="/about">
            {nav.about}
          </Link>
          <Link className={linkClass("/blog")} href="/blog">
            {nav.blog}
          </Link>
          <Link className={linkClass("/contact")} href="/contact">
            {nav.contact}
          </Link>
        </Container>
      </div>
    </header>
  );
}
