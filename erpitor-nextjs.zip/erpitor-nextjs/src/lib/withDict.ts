import type { GetStaticPropsContext } from "next";
import { getDictionary, type Dictionary, type Locale, isLocale } from "@/lib/i18n";
import { SITE } from "@/lib/site";

export async function loadDict(ctx: GetStaticPropsContext): Promise<Dictionary> {
  const raw = ctx.locale || SITE.defaultLocale;
  const locale: Locale = isLocale(raw) ? raw : SITE.defaultLocale;
  return getDictionary(locale);
}

export function getLocale(ctx: GetStaticPropsContext): Locale {
  const raw = ctx.locale || SITE.defaultLocale;
  return isLocale(raw) ? raw : SITE.defaultLocale;
}
