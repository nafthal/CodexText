export const SITE = {
  name: "Erpitor OÜ",
  domain: "erpitor.com",
  // Used for canonical URLs and hreflang. Override in production via NEXT_PUBLIC_SITE_URL.
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://www.erpitor.com",
  defaultLocale: "et" as const,
  locales: ["et", "en"] as const,
  contact: {
    email: "mnafthal@erpitor.com",
    phone: "+372 50 64 989",
    address: "Mähe tee 25-22, 11912 Tallinn, Estonia",
  },
};
