import fs from "fs/promises";
import path from "path";
import matter from "gray-matter";
import { remark } from "remark";
import html from "remark-html";
import type { Locale } from "@/lib/i18n";

export type BlogPostMeta = {
  slug: string;
  locale: Locale;
  title: string;
  description: string;
  date: string; // ISO date
  tags: string[];
};

const BLOG_DIR = path.join(process.cwd(), "src", "content", "blog");

function postPath(locale: Locale, slug: string) {
  return path.join(BLOG_DIR, locale, `${slug}.md`);
}

export async function listPostSlugs(locale: Locale): Promise<string[]> {
  const dir = path.join(BLOG_DIR, locale);
  const entries = await fs.readdir(dir, { withFileTypes: true });
  return entries
    .filter((e) => e.isFile() && e.name.endsWith(".md"))
    .map((e) => e.name.replace(/\.md$/, ""));
}

export async function getPostMeta(locale: Locale, slug: string): Promise<BlogPostMeta> {
  const raw = await fs.readFile(postPath(locale, slug), "utf8");
  const { data } = matter(raw);

  const title = String(data.title ?? slug);
  const description = String(data.description ?? "");
  const date = String(data.date ?? new Date().toISOString().slice(0, 10));
  const tags = Array.isArray(data.tags) ? data.tags.map(String) : [];

  return { slug, locale, title, description, date, tags };
}

export async function listPosts(locale: Locale): Promise<BlogPostMeta[]> {
  const slugs = await listPostSlugs(locale);
  const metas = await Promise.all(slugs.map((s) => getPostMeta(locale, s)));
  return metas.sort((a, b) => (a.date < b.date ? 1 : -1));
}

export async function getPostHtml(locale: Locale, slug: string) {
  const raw = await fs.readFile(postPath(locale, slug), "utf8");
  const { content, data } = matter(raw);

  const processed = await remark().use(html, { sanitize: false }).process(content);
  const contentHtml = processed.toString();

  const meta = await getPostMeta(locale, slug);
  return { meta: { ...meta, ...data }, contentHtml };
}
