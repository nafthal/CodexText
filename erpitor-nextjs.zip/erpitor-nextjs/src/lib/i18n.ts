import type en from "@/content/dictionaries/en.json";
import type et from "@/content/dictionaries/et.json";

export type Locale = "et" | "en";
export type Dictionary = typeof en | typeof et;

const dictionaries = {
  en: () => import("@/content/dictionaries/en.json").then((m) => m.default),
  et: () => import("@/content/dictionaries/et.json").then((m) => m.default),
};

export async function getDictionary(locale: Locale): Promise<Dictionary> {
  const loader = dictionaries[locale] ?? dictionaries.et;
  return loader();
}

export function isLocale(value: string): value is Locale {
  return value === "et" || value === "en";
}
