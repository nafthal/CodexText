import { SITE } from "@/lib/site";

export function absoluteUrl(pathname: string) {
  const base = SITE.url.replace(/\/$/, "");
  const path = pathname.startsWith("/") ? pathname : `/${pathname}`;
  return `${base}${path}`;
}

/**
 * Next.js i18n behavior:
 * - default locale (et) has no prefix
 * - other locale (en) is prefixed with /en
 */
export function localePath(locale: string, pathname: string) {
  const clean = pathname.startsWith("/") ? pathname : `/${pathname}`;
  if (locale === SITE.defaultLocale) return clean;
  return `/${locale}${clean === "/" ? "" : clean}`;
}
