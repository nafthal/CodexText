import Link from "next/link";
import type { GetStaticProps } from "next";

import { SiteLayout } from "@/layouts/SiteLayout";
import { SEO } from "@/components/SEO";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { Button } from "@/components/Button";

import { loadDict, getLocale } from "@/lib/withDict";
import type { Dictionary, Locale } from "@/lib/i18n";
import { listPosts, type BlogPostMeta } from "@/lib/blog";
import { caseStudies } from "@/content/case-studies";

type Props = {
  dict: Dictionary;
  locale: Locale;
  latestPosts: BlogPostMeta[];
};

export default function HomePage({ dict, locale, latestPosts }: Props) {
  const featured = caseStudies.filter((c) => c.featured).slice(0, 4);

  return (
    <SiteLayout dict={dict}>
      <SEO title={dict.meta.defaultTitle} description={dict.meta.defaultDescription} />

      {/* Hero */}
      <div className="relative overflow-hidden bg-gradient-to-b from-brand-50 to-white">
        <Container className="py-16 sm:py-20">
          <div className="grid gap-10 lg:grid-cols-12 lg:items-center">
            <div className="lg:col-span-7">
              <Badge>{dict.home.trustTitle}</Badge>
              <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
                {dict.home.heroTitle}
              </h1>
              <p className="mt-5 max-w-2xl text-lg text-slate-700">
                {dict.home.heroSubtitle}
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/contact" className="no-underline">
                  <Button>{dict.cta.freeConsultation}</Button>
                </Link>
                <Link href="/case-studies" className="no-underline">
                  <Button variant="secondary">{dict.cta.viewCaseStudies}</Button>
                </Link>
              </div>
            </div>

            <div className="lg:col-span-5">
              <Card className="overflow-hidden">
                <CardHeader>
                  <div className="text-sm font-semibold text-slate-900">What you get</div>
                  <p className="mt-1 text-sm text-slate-600">
                    Contemporary delivery, strong documentation, predictable outcomes.
                  </p>
                </CardHeader>
                <CardBody>
                  <div className="grid gap-4">
                    {dict.home.valueProps.map((p) => (
                      <div key={p.title} className="rounded-xl bg-brand-50 p-4">
                        <div className="text-sm font-semibold text-brand-900">{p.title}</div>
                        <div className="mt-1 text-sm text-slate-700">{p.text}</div>
                      </div>
                    ))}
                  </div>
                </CardBody>
              </Card>
            </div>
          </div>
        </Container>
      </div>

      {/* Services */}
      <Section>
        <Container>
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">{dict.home.sections.servicesTitle}</h2>
              <p className="mt-2 text-slate-600">{dict.services.intro}</p>
            </div>
            <Link href="/services" className="no-underline">
              <Button variant="ghost">{dict.cta.learnMore}</Button>
            </Link>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-2">
            {dict.services.cards.map((c) => (
              <Card key={c.title}>
                <CardHeader>
                  <h3 className="text-lg font-bold text-slate-900">{c.title}</h3>
                </CardHeader>
                <CardBody>
                  <p className="text-slate-700">{c.text}</p>
                </CardBody>
              </Card>
            ))}
          </div>
        </Container>
      </Section>

      {/* Industries */}
      <Section className="bg-slate-50">
        <Container>
          <h2 className="text-2xl font-bold text-slate-900">{dict.home.sections.industriesTitle}</h2>
          <p className="mt-2 text-slate-600">{dict.industries.intro}</p>

          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {dict.industries.items.map((i) => (
              <Card key={i.title} className="h-full">
                <CardHeader>
                  <h3 className="text-base font-bold text-slate-900">{i.title}</h3>
                </CardHeader>
                <CardBody>
                  <p className="text-sm text-slate-700">{i.text}</p>
                </CardBody>
              </Card>
            ))}
          </div>
        </Container>
      </Section>

      {/* Case studies */}
      <Section>
        <Container>
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">{dict.home.sections.caseStudiesTitle}</h2>
              <p className="mt-2 text-slate-600">{dict.caseStudies.intro}</p>
            </div>
            <Link href="/case-studies" className="no-underline">
              <Button variant="ghost">{dict.cta.viewCaseStudies}</Button>
            </Link>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-2">
            {featured.map((c) => (
              <Card key={c.id} className="h-full">
                <CardHeader>
                  <div className="flex flex-wrap items-center gap-2">
                    {c.featured ? <Badge>{dict.caseStudies.featuredLabel}</Badge> : null}
                    <Badge className="bg-slate-50 text-slate-700 ring-slate-200">{c.product}</Badge>
                    <Badge className="bg-slate-50 text-slate-700 ring-slate-200">{c.years}</Badge>
                  </div>
                  <h3 className="mt-3 text-lg font-bold text-slate-900">{c.company}</h3>
                  <p className="mt-1 text-sm text-slate-600">{c.country}</p>
                </CardHeader>
                <CardBody>
                  <p className="text-slate-700">{c.summary[locale]}</p>
                </CardBody>
              </Card>
            ))}
          </div>
        </Container>
      </Section>

      {/* Process */}
      <Section className="bg-gradient-to-b from-white to-brand-50">
        <Container>
          <h2 className="text-2xl font-bold text-slate-900">{dict.home.sections.processTitle}</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {dict.home.processSteps.map((s) => (
              <Card key={s.title} className="h-full">
                <CardHeader>
                  <h3 className="text-base font-bold text-slate-900">{s.title}</h3>
                </CardHeader>
                <CardBody>
                  <p className="text-sm text-slate-700">{s.text}</p>
                </CardBody>
              </Card>
            ))}
          </div>
        </Container>
      </Section>

      {/* Blog preview */}
      <Section>
        <Container>
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">{dict.home.sections.blogTitle}</h2>
              <p className="mt-2 text-slate-600">{dict.blog.intro}</p>
            </div>
            <Link href="/blog" className="no-underline">
              <Button variant="ghost">{dict.cta.learnMore}</Button>
            </Link>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {latestPosts.map((p) => (
              <Card key={p.slug} className="h-full">
                <CardHeader>
                  <Badge className="bg-slate-50 text-slate-700 ring-slate-200">{p.date}</Badge>
                  <h3 className="mt-3 text-base font-bold text-slate-900">{p.title}</h3>
                  <p className="mt-2 text-sm text-slate-600">{p.description}</p>
                </CardHeader>
                <CardBody>
                  <Link href={`/blog/${p.slug}`} className="no-underline">
                    <Button variant="secondary">{dict.cta.learnMore}</Button>
                  </Link>
                </CardBody>
              </Card>
            ))}
          </div>
        </Container>
      </Section>

      {/* Contact CTA */}
      <Section className="bg-slate-50">
        <Container>
          <div className="rounded-3xl border border-slate-200 bg-white p-8 sm:p-10">
            <h2 className="text-2xl font-bold text-slate-900">{dict.home.sections.contactTitle}</h2>
            <p className="mt-2 max-w-2xl text-slate-700">{dict.contact.intro}</p>
            <div className="mt-6">
              <Link href="/contact" className="no-underline">
                <Button>{dict.cta.freeConsultation}</Button>
              </Link>
            </div>
          </div>
        </Container>
      </Section>
    </SiteLayout>
  );
}

export const getStaticProps: GetStaticProps<Props> = async (ctx) => {
  const dict = await loadDict(ctx);
  const locale = getLocale(ctx);
  const latestPosts = (await listPosts(locale)).slice(0, 3);

  return {
    props: {
      dict,
      locale,
      latestPosts,
    },
  };
};
