import type { GetStaticProps } from "next";

import { SiteLayout } from "@/layouts/SiteLayout";
import { SEO } from "@/components/SEO";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { ContactForm } from "@/components/ContactForm";

import { loadDict } from "@/lib/withDict";
import type { Dictionary } from "@/lib/i18n";
import { SITE } from "@/lib/site";

type Props = { dict: Dictionary };

export default function ContactPage({ dict }: Props) {
  return (
    <SiteLayout dict={dict}>
      <SEO title={dict.contact.title} description={dict.contact.intro} />

      <Section>
        <Container>
          <div className="grid gap-8 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
                {dict.contact.title}
              </h1>
              <p className="mt-3 text-lg text-slate-700">{dict.contact.intro}</p>

              <div className="mt-8 space-y-4 rounded-3xl border border-slate-200 bg-slate-50 p-6">
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">Email</div>
                  <a className="text-sm font-semibold text-brand-800 hover:text-brand-900" href={`mailto:${SITE.contact.email}`}>
                    {SITE.contact.email}
                  </a>
                </div>
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">Phone</div>
                  <a className="text-sm font-semibold text-brand-800 hover:text-brand-900" href={`tel:${SITE.contact.phone.replace(/\s+/g, "")}`}>
                    {SITE.contact.phone}
                  </a>
                </div>
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">Address</div>
                  <div className="text-sm text-slate-700">{SITE.contact.address}</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7">
              <Card>
                <CardHeader>
                  <h2 className="text-lg font-bold text-slate-900">{dict.cta.freeConsultation}</h2>
                  <p className="mt-1 text-sm text-slate-600">
                    We usually respond within 1–2 business days.
                  </p>
                </CardHeader>
                <CardBody>
                  <ContactForm dict={dict.contact.form} />
                </CardBody>
              </Card>

              <p className="mt-4 text-xs text-slate-500">
                Note: email sending is handled via <code className="rounded bg-slate-100 px-1">/api/contact</code>. Configure SMTP
                in <code className="rounded bg-slate-100 px-1">.env.local</code> for production.
              </p>
            </div>
          </div>
        </Container>
      </Section>
    </SiteLayout>
  );
}

export const getStaticProps: GetStaticProps<Props> = async (ctx) => {
  const dict = await loadDict(ctx);
  return { props: { dict } };
};
