import type { GetStaticProps } from "next";
import { useMemo, useState } from "react";
import Link from "next/link";

import { SiteLayout } from "@/layouts/SiteLayout";
import { SEO } from "@/components/SEO";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Badge } from "@/components/Badge";
import { Button } from "@/components/Button";

import { loadDict, getLocale } from "@/lib/withDict";
import type { Dictionary, Locale } from "@/lib/i18n";
import { caseStudies, type CaseStudy } from "@/content/case-studies";

type Props = { dict: Dictionary; locale: Locale };

const productOptions: Array<CaseStudy["product"] | "All"> = ["All", "Epicor Kinetic", "Epicor ERP", "Epicor iScala", "Other"];

export default function CaseStudiesPage({ dict, locale }: Props) {
  const [product, setProduct] = useState<(typeof productOptions)[number]>("All");

  const filtered = useMemo(() => {
    const list = caseStudies.slice().sort((a, b) => (a.featured === b.featured ? 0 : a.featured ? -1 : 1));
    if (product === "All") return list;
    return list.filter((c) => c.product === product);
  }, [product]);

  return (
    <SiteLayout dict={dict}>
      <SEO title={dict.caseStudies.title} description={dict.caseStudies.intro} />

      <Section>
        <Container>
          <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
                {dict.caseStudies.title}
              </h1>
              <p className="mt-3 max-w-3xl text-lg text-slate-700">{dict.caseStudies.intro}</p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {productOptions.map((p) => (
                <button
                  key={p}
                  className={[
                    "rounded-full px-4 py-2 text-sm font-semibold transition",
                    p === product ? "bg-brand-700 text-white" : "bg-slate-100 text-slate-700 hover:bg-slate-200",
                  ].join(" ")}
                  onClick={() => setProduct(p)}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {filtered.map((c) => (
              <Card key={c.id} className="h-full">
                <CardHeader>
                  <div className="flex flex-wrap items-center gap-2">
                    {c.featured ? <Badge>{dict.caseStudies.featuredLabel}</Badge> : null}
                    <Badge className="bg-slate-50 text-slate-700 ring-slate-200">{c.product}</Badge>
                    <Badge className="bg-slate-50 text-slate-700 ring-slate-200">{c.years}</Badge>
                  </div>
                  <h2 className="mt-3 text-lg font-bold text-slate-900">{c.company}</h2>
                  <p className="mt-1 text-sm text-slate-600">{c.country}</p>
                </CardHeader>
                <CardBody>
                  <p className="text-slate-700">{c.summary[locale]}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {c.tags.map((t) => (
                      <Badge key={t} className="bg-white text-slate-700 ring-slate-200">{t}</Badge>
                    ))}
                  </div>
                </CardBody>
              </Card>
            ))}
          </div>

          <div className="mt-12 rounded-3xl border border-slate-200 bg-slate-50 p-8">
            <h2 className="text-xl font-bold text-slate-900">{dict.cta.freeConsultation}</h2>
            <p className="mt-2 max-w-2xl text-slate-700">
              Tell us your industry, scope and timeline—we’ll share the most relevant references and propose a next step.
            </p>
            <div className="mt-6">
              <Link href="/contact" className="no-underline">
                <Button>{dict.cta.freeConsultation}</Button>
              </Link>
            </div>
          </div>
        </Container>
      </Section>
    </SiteLayout>
  );
}

export const getStaticProps: GetStaticProps<Props> = async (ctx) => {
  const dict = await loadDict(ctx);
  const locale = getLocale(ctx);
  return { props: { dict, locale } };
};
