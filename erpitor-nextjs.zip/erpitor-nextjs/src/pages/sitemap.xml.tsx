import type { GetServerSideProps } from "next";
import { SITE } from "@/lib/site";
import { absoluteUrl } from "@/lib/seo";
import { listPostSlugs } from "@/lib/blog";

function xmlEscape(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

export const getServerSideProps: GetServerSideProps = async ({ res }) => {
  const staticPaths = [
    "/",
    "/services",
    "/industries",
    "/case-studies",
    "/about",
    "/blog",
    "/contact",
    "/privacy",
  ];

  const enPaths = staticPaths
    .filter((p) => p !== "/") // English home is /en
    .map((p) => `/en${p}`);
  enPaths.unshift("/en");

  const etPosts = await listPostSlugs("et");
  const enPosts = await listPostSlugs("en");

  const urls = [
    ...staticPaths.map((p) => absoluteUrl(p)),
    ...enPaths.map((p) => absoluteUrl(p)),
    ...etPosts.map((slug) => absoluteUrl(`/blog/${slug}`)),
    ...enPosts.map((slug) => absoluteUrl(`/en/blog/${slug}`)),
  ];

  const body = `<?xml version="1.0" encoding="UTF-8"?>\n` +
    `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
    urls.map((u) => `  <url><loc>${xmlEscape(u)}</loc></url>`).join("\n") +
    `\n</urlset>\n`;

  res.setHeader("Content-Type", "text/xml");
  res.write(body);
  res.end();

  return { props: {} };
};

export default function SitemapXml() {
  return null;
}
