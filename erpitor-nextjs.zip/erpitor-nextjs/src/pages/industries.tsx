import type { GetStaticProps } from "next";
import Link from "next/link";

import { SiteLayout } from "@/layouts/SiteLayout";
import { SEO } from "@/components/SEO";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";

import { loadDict } from "@/lib/withDict";
import type { Dictionary } from "@/lib/i18n";

type Props = { dict: Dictionary };

export default function IndustriesPage({ dict }: Props) {
  return (
    <SiteLayout dict={dict}>
      <SEO title={dict.industries.title} description={dict.industries.intro} />

      <Section>
        <Container>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
            {dict.industries.title}
          </h1>
          <p className="mt-3 max-w-3xl text-lg text-slate-700">{dict.industries.intro}</p>

          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {dict.industries.items.map((i) => (
              <Card key={i.title} className="h-full">
                <CardHeader>
                  <h2 className="text-base font-bold text-slate-900">{i.title}</h2>
                </CardHeader>
                <CardBody>
                  <p className="text-sm text-slate-700">{i.text}</p>
                </CardBody>
              </Card>
            ))}
          </div>

          <div className="mt-12 rounded-3xl border border-slate-200 bg-slate-50 p-8">
            <h2 className="text-xl font-bold text-slate-900">Next step</h2>
            <p className="mt-2 max-w-2xl text-slate-700">
              If you’re evaluating a new ERP system or planning to modernize Epicor, we can run a short discovery to clarify scope and risks.
            </p>
            <div className="mt-6">
              <Link href="/contact" className="no-underline">
                <Button>{dict.cta.freeConsultation}</Button>
              </Link>
            </div>
          </div>
        </Container>
      </Section>
    </SiteLayout>
  );
}

export const getStaticProps: GetStaticProps<Props> = async (ctx) => {
  const dict = await loadDict(ctx);
  return { props: { dict } };
};
