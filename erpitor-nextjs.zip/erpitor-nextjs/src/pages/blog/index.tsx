import type { GetStaticProps } from "next";
import Link from "next/link";

import { SiteLayout } from "@/layouts/SiteLayout";
import { SEO } from "@/components/SEO";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Badge } from "@/components/Badge";

import { loadDict, getLocale } from "@/lib/withDict";
import type { Dictionary, Locale } from "@/lib/i18n";
import { listPosts, type BlogPostMeta } from "@/lib/blog";

type Props = {
  dict: Dictionary;
  locale: Locale;
  posts: BlogPostMeta[];
};

export default function BlogIndexPage({ dict, posts }: Props) {
  return (
    <SiteLayout dict={dict}>
      <SEO title={dict.blog.title} description={dict.blog.intro} />

      <Section>
        <Container>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">{dict.blog.title}</h1>
          <p className="mt-3 max-w-3xl text-lg text-slate-700">{dict.blog.intro}</p>

          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {posts.map((p) => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="no-underline">
                <Card className="h-full transition hover:shadow-md">
                  <CardHeader>
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge className="bg-slate-50 text-slate-700 ring-slate-200">{p.date}</Badge>
                      {p.tags.slice(0, 2).map((t) => (
                        <Badge key={t} className="bg-white text-slate-700 ring-slate-200">{t}</Badge>
                      ))}
                    </div>
                    <h2 className="mt-3 text-lg font-bold text-slate-900">{p.title}</h2>
                    <p className="mt-2 text-sm text-slate-600">{p.description}</p>
                  </CardHeader>
                  <CardBody>
                    <span className="text-sm font-semibold text-brand-800">Read →</span>
                  </CardBody>
                </Card>
              </Link>
            ))}
          </div>
        </Container>
      </Section>
    </SiteLayout>
  );
}

export const getStaticProps: GetStaticProps<Props> = async (ctx) => {
  const dict = await loadDict(ctx);
  const locale = getLocale(ctx);
  const posts = await listPosts(locale);

  return {
    props: { dict, locale, posts },
  };
};
