import type { GetStaticPaths, GetStaticProps } from "next";
import Link from "next/link";

import { SiteLayout } from "@/layouts/SiteLayout";
import { SEO } from "@/components/SEO";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Badge } from "@/components/Badge";
import { Markdown } from "@/components/Markdown";

import { loadDict, getLocale } from "@/lib/withDict";
import type { Dictionary, Locale } from "@/lib/i18n";
import { getPostHtml, listPostSlugs } from "@/lib/blog";

type Props = {
  dict: Dictionary;
  locale: Locale;
  meta: {
    title: string;
    description: string;
    date: string;
    tags: string[];
  };
  contentHtml: string;
};

export default function BlogPostPage({ dict, meta, contentHtml }: Props) {
  return (
    <SiteLayout dict={dict}>
      <SEO title={meta.title} description={meta.description} />

      <Section>
        <Container>
          <Link href="/blog" className="text-sm font-semibold text-brand-800 hover:text-brand-900">
            ← {dict.blog.title}
          </Link>

          <h1 className="mt-4 text-3xl font-extrabold tracking-tight text-slate-900">{meta.title}</h1>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Badge className="bg-slate-50 text-slate-700 ring-slate-200">{meta.date}</Badge>
            {meta.tags.map((t) => (
              <Badge key={t} className="bg-white text-slate-700 ring-slate-200">{t}</Badge>
            ))}
          </div>

          <div className="mt-8 rounded-3xl border border-slate-200 bg-white p-6 sm:p-10">
            <Markdown html={contentHtml} />
          </div>
        </Container>
      </Section>
    </SiteLayout>
  );
}

export const getStaticPaths: GetStaticPaths = async ({ locales }) => {
  const paths: { params: { slug: string }; locale?: string }[] = [];

  const activeLocales = (locales || ["et", "en"]) as Locale[];
  for (const loc of activeLocales) {
    const slugs = await listPostSlugs(loc);
    for (const slug of slugs) {
      paths.push({ params: { slug }, locale: loc });
    }
  }

  return { paths, fallback: false };
};

export const getStaticProps: GetStaticProps<Props> = async (ctx) => {
  const dict = await loadDict(ctx);
  const locale = getLocale(ctx);
  const slug = String(ctx.params?.slug || "");

  const post = await getPostHtml(locale, slug);

  return {
    props: {
      dict,
      locale,
      meta: {
        title: post.meta.title as string,
        description: post.meta.description as string,
        date: post.meta.date as string,
        tags: (post.meta.tags as string[]) || [],
      },
      contentHtml: post.contentHtml,
    },
  };
};
