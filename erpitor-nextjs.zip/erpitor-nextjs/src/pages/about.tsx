import type { GetStaticProps } from "next";
import Link from "next/link";

import { SiteLayout } from "@/layouts/SiteLayout";
import { SEO } from "@/components/SEO";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";

import { loadDict, getLocale } from "@/lib/withDict";
import type { Dictionary, Locale } from "@/lib/i18n";

type Props = { dict: Dictionary; locale: Locale };

export default function AboutPage({ dict }: Props) {
  return (
    <SiteLayout dict={dict}>
      <SEO title={dict.about.title} description={dict.about.intro} />

      <Section>
        <Container>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">{dict.about.title}</h1>
          <p className="mt-3 max-w-3xl text-lg text-slate-700">{dict.about.intro}</p>

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader>
                <h2 className="text-base font-bold text-slate-900">Focus</h2>
              </CardHeader>
              <CardBody>
                <p className="text-sm text-slate-700">
                  Epicor Kinetic and Epicor iScala consulting, implementation support, integrations and custom development.
                </p>
              </CardBody>
            </Card>

            <Card>
              <CardHeader>
                <h2 className="text-base font-bold text-slate-900">Approach</h2>
              </CardHeader>
              <CardBody>
                <p className="text-sm text-slate-700">
                  Clear scope, early testing, maintainable solutions and transparent communication.
                </p>
              </CardBody>
            </Card>

            <Card>
              <CardHeader>
                <h2 className="text-base font-bold text-slate-900">Experience</h2>
              </CardHeader>
              <CardBody>
                <p className="text-sm text-slate-700">
                  International ERP delivery experience across manufacturing, logistics and multi-company environments.
                </p>
              </CardBody>
            </Card>
          </div>

          <div className="mt-12 rounded-3xl border border-slate-200 bg-slate-50 p-8">
            <h2 className="text-xl font-bold text-slate-900">{dict.cta.freeConsultation}</h2>
            <p className="mt-2 max-w-2xl text-slate-700">
              If you’re planning a new ERP system or want to modernize an existing Epicor environment, let’s talk.
            </p>
            <div className="mt-6">
              <Link href="/contact" className="no-underline">
                <Button>{dict.cta.freeConsultation}</Button>
              </Link>
            </div>
          </div>
        </Container>
      </Section>
    </SiteLayout>
  );
}

export const getStaticProps: GetStaticProps<Props> = async (ctx) => {
  const dict = await loadDict(ctx);
  const locale = getLocale(ctx);
  return { props: { dict, locale } };
};
