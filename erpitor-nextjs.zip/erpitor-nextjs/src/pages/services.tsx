import type { GetStaticProps } from "next";
import Link from "next/link";

import { SiteLayout } from "@/layouts/SiteLayout";
import { SEO } from "@/components/SEO";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";
import { Card, CardBody, CardHeader } from "@/components/Card";
import { Button } from "@/components/Button";

import { loadDict } from "@/lib/withDict";
import type { Dictionary } from "@/lib/i18n";

type Props = { dict: Dictionary };

export default function ServicesPage({ dict }: Props) {
  return (
    <SiteLayout dict={dict}>
      <SEO title={dict.services.title} description={dict.services.intro} />

      <Section>
        <Container>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
            {dict.services.title}
          </h1>
          <p className="mt-3 max-w-3xl text-lg text-slate-700">{dict.services.intro}</p>

          <div className="mt-10 grid gap-6 md:grid-cols-2">
            {dict.services.cards.map((c) => (
              <Card key={c.title} className="h-full">
                <CardHeader>
                  <h2 className="text-lg font-bold text-slate-900">{c.title}</h2>
                </CardHeader>
                <CardBody>
                  <p className="text-slate-700">{c.text}</p>
                </CardBody>
              </Card>
            ))}
          </div>

          <div className="mt-12 rounded-3xl border border-slate-200 bg-slate-50 p-8">
            <h2 className="text-xl font-bold text-slate-900">
              {dict.cta.freeConsultation}
            </h2>
            <p className="mt-2 max-w-2xl text-slate-700">
              Share your goals, current systems, and timeline—we’ll propose the next step and a realistic plan.
            </p>
            <div className="mt-6">
              <Link href="/contact" className="no-underline">
                <Button>{dict.cta.freeConsultation}</Button>
              </Link>
            </div>
          </div>
        </Container>
      </Section>
    </SiteLayout>
  );
}

export const getStaticProps: GetStaticProps<Props> = async (ctx) => {
  const dict = await loadDict(ctx);
  return { props: { dict } };
};
