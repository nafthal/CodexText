import type { GetStaticProps } from "next";
import { useRouter } from "next/router";

import { SiteLayout } from "@/layouts/SiteLayout";
import { SEO } from "@/components/SEO";
import { Container } from "@/components/Container";
import { Section } from "@/components/Section";

import { loadDict } from "@/lib/withDict";
import type { Dictionary } from "@/lib/i18n";

type Props = { dict: Dictionary };

export default function PrivacyPage({ dict }: Props) {
  const router = useRouter();
  const locale = router.locale || "et";

  const title = locale === "et" ? "Privaatsus" : "Privacy";
  const body =
    locale === "et"
      ? "See on privaatsuse lehe placeholder. Lisa siia küpsiste, analüütika ja kontaktivormi andmetöötluse kirjeldus."
      : "This is a placeholder privacy page. Add details about cookies, analytics and contact form data processing.";

  return (
    <SiteLayout dict={dict}>
      <SEO title={title} description={body} noIndex />

      <Section>
        <Container>
          <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">{title}</h1>
          <p className="mt-4 max-w-3xl text-slate-700">{body}</p>
        </Container>
      </Section>
    </SiteLayout>
  );
}

export const getStaticProps: GetStaticProps<Props> = async (ctx) => {
  const dict = await loadDict(ctx);
  return { props: { dict } };
};
