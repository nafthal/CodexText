import type { NextApiRequest, NextApiResponse } from "next";
import nodemailer from "nodemailer";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(1).max(200),
  company: z.string().max(200).optional().default(""),
  email: z.string().email().max(200),
  phone: z.string().max(50).optional().default(""),
  message: z.string().max(5000).optional().default(""),
  website: z.string().optional().default(""), // honeypot
});

type Data =
  | { ok: true }
  | { ok: false; error: string };

const RATE_LIMIT = {
  windowMs: 60 * 60 * 1000, // 1h
  max: 10,
};

const hits = new Map<string, { count: number; resetAt: number }>();

function getClientIp(req: NextApiRequest) {
  const xf = req.headers["x-forwarded-for"];
  if (typeof xf === "string" && xf.length > 0) return xf.split(",")[0].trim();
  return req.socket.remoteAddress || "unknown";
}

function rateLimit(ip: string) {
  const now = Date.now();
  const current = hits.get(ip);
  if (!current || now > current.resetAt) {
    hits.set(ip, { count: 1, resetAt: now + RATE_LIMIT.windowMs });
    return true;
  }
  if (current.count >= RATE_LIMIT.max) return false;
  current.count += 1;
  hits.set(ip, current);
  return true;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse<Data>) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ ok: false, error: "Method not allowed" });
  }

  const ip = getClientIp(req);
  if (!rateLimit(ip)) {
    return res.status(429).json({ ok: false, error: "Too many requests" });
  }

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: "Invalid input" });
  }

  // Honeypot: pretend success for bots.
  if (parsed.data.website && parsed.data.website.trim().length > 0) {
    return res.status(200).json({ ok: true });
  }

  const {
    SMTP_HOST,
    SMTP_PORT,
    SMTP_USER,
    SMTP_PASS,
    CONTACT_TO,
    CONTACT_FROM,
  } = process.env;

  if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS || !CONTACT_TO || !CONTACT_FROM) {
    return res.status(500).json({
      ok: false,
      error: "Email service is not configured",
    });
  }

  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: Number(SMTP_PORT) === 465,
    auth: {
      user: SMTP_USER,
      pass: SMTP_PASS,
    },
  });

  const { name, company, email, phone, message } = parsed.data;

  const subject = `New ERP consultation request from ${name}`;
  const text =
    [
      `Name: ${name}`,
      `Company: ${company || "-"}`,
      `Email: ${email}`,
      `Phone: ${phone || "-"}`,
      "",
      `Message:`,
      message || "-",
      "",
      `IP: ${ip}`,
      `Time: ${new Date().toISOString()}`,
    ].join("\n");

  try {
    await transporter.sendMail({
      from: CONTACT_FROM,
      to: CONTACT_TO,
      replyTo: email,
      subject,
      text,
    });

    return res.status(200).json({ ok: true });
  } catch (e) {
    console.error("Email send failed", e);
    return res.status(500).json({ ok: false, error: "Unable to send email" });
  }
}
